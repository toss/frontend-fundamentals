import { mean } from "./mean";
export function callMean() {
  return mean([1, 2, 3, 4, 5]);
}

export { clamp } from "./clamp";
export { inRange } from "./inRange";
export { median } from "./median";
export { medianBy } from "./medianBy";
export { random } from "./random";
export { randomInt } from "./randomInt";
export { range } from "./range";
export { rangeRight } from "./rangeRight";
export { round } from "./round";
export { sum } from "./sum";
export { sumBy } from "./sumBy";
